package com.example.accountapp.Bean

class Inventory {
    var itemDesc: String? = null
    var quantity: Int = 0
    var itemCode: String? = null
    var date: String? = null
    var volume: Float = 0.toFloat()

    }
