package com.example.accountapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Spinner
import android.widget.ArrayAdapter
import android.widget.EditText


class costadd : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {


        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_costadd)
        val text:EditText=findViewById(R.id.number)
        var spinner=findViewById<Spinner>(R.id.spinner)
        var adapter=ArrayAdapter(this,R.layout.spinner_item,resources.getStringArray(R.array.detail))
        adapter.setDropDownViewResource(R.layout.dropdown_stytle)
        spinner.adapter=adapter
    }


    }

