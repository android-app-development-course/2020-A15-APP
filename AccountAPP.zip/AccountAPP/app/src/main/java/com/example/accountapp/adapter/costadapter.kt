package com.example.accountapp.adapter

import android.widget.BaseAdapter
import android.R
import android.content.Context
import android.widget.TextView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import java.nio.file.Files.size



class costadapter(context: Context, list: List<String>):BaseAdapter(){
    private var context: Context?=null
    private lateinit var list: List<String>
    private var inflater: LayoutInflater? = null

    init {
        this.context = context
        this.list = list
        inflater = LayoutInflater.from(this.context)
    }


    override fun getCount(): Int {
        return list.size
    }

    override fun getItem(position: Int): Any {
        return list[position]
    }

    override fun getItemId(position: Int): Long {
        return position.toLong()
    }

    override fun getView(position: Int, convertView: View, parent: ViewGroup): View {
        var convertView = convertView
        convertView = LayoutInflater.from(context).inflate(com.example.accountapp.R.layout.spinner_item, null)
        val tvgetView = convertView.findViewById(com.example.accountapp.R.id.textView32) as TextView
        tvgetView.text = getItem(position).toString()
        return convertView
    }

   override fun getDropDownView(position: Int, convertView: View, parent: ViewGroup): View {
        var convertView = convertView
        convertView = LayoutInflater.from(context).inflate(com.example.accountapp.R.layout.dropdown_stytle, null)
        val tvdropdowview = convertView.findViewById(com.example.accountapp.R.id.textView3333) as TextView
        tvdropdowview.text = getItem(position).toString()
        return convertView
    }

}