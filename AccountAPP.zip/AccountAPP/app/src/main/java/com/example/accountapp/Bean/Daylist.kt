package com.example.accountapp.Bean

class Daylist {
    private var money:Float=0.toFloat()
    private var type:String=""
    fun setmoney(float: Float) {this.money=float}
    fun settype(string: String){this.type=string}
    fun getmoney():Float{return money}
    fun gettype():String{return type}

}