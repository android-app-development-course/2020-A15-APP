package com.example.davidchen.blogdemo.adapter

import android.R
import android.content.Context
import android.view.View
import android.widget.TextView


import com.example.accountapp.Bean.Inventory
import android.app.Activity



/**
 * 清单列表adapter
 *
 *
 * Created by DavidChen on 2018/5/30.
 */

class InventoryAdapter(context: Context, data: List<Inventory>) :
    BaseRecyclerViewAdapter<Inventory>(context, data, com.example.accountapp.R.layout.item_inventroy) {


    private var mDeleteClickListener: OnDeleteClickLister? = null


    override fun onBindData(holder: RecyclerViewHolder, bean: Inventory, position: Int) {
        val view = holder.getView(com.example.accountapp.R.id.tv_delete)
        view!!.tag = position
        if (!view.hasOnClickListeners()) {
            view.setOnClickListener { v ->
                if (mDeleteClickListener != null) {
                    mDeleteClickListener!!.onDeleteClick(v, v.tag as Int)
                }
            }
        }
        (holder.getView(com.example.accountapp.R.id.tv_item_desc) as TextView).text = bean.itemDesc
        val quantity = bean.quantity.toString()
        (holder.getView(com.example.accountapp.R.id.tv_quantity) as TextView).text = quantity
        val detail = bean.itemCode + "/" + bean.date
        (holder.getView(com.example.accountapp.R.id.tv_detail) as TextView).text = detail
        val volume = bean.volume.toString()
        (holder.getView(com.example.accountapp.R.id.tv_volume) as TextView).text = volume
    }

    fun setOnDeleteClickListener(listener: OnDeleteClickLister) {
        this.mDeleteClickListener = listener
    }

    interface OnDeleteClickLister {
        fun onDeleteClick(view: View, position: Int)
    }
}