package com.example.accountapp.ui.home

import android.app.Activity
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Spinner
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.core.content.contentValuesOf
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.accountapp.Bean.Inventory
import com.example.accountapp.First
import com.example.accountapp.R
import com.example.accountapp.SlideRecyclerView
import kotlinx.android.synthetic.main.activity_recyclerview.*
import java.util.*
import kotlin.collections.ArrayList
import com.example.davidchen.blogdemo.adapter.InventoryAdapter






class HomeFragment : Fragment() {

    private var recycler_view_list: SlideRecyclerView? = null

    private var mInventoryAdapter: InventoryAdapter? = null
    private lateinit var homeViewModel: HomeViewModel
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        homeViewModel =
            ViewModelProviders.of(this).get(HomeViewModel::class.java)
        val root = inflater.inflate(com.example.accountapp.R.layout.fragment_home, container, false)


        return root
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        recycler_view_list=view!!.findViewById(R.id.recycler_view_list)
        recycler_view_list?.layoutManager=LinearLayoutManager(activity,LinearLayoutManager.VERTICAL, false)
        var inventory:Inventory
        var random:Random= Random()
        var mInventories= ArrayList<Inventory>()
        for(i in 0..50){
            inventory= Inventory()
            inventory.itemDesc=("测试数据" + i);
            inventory.quantity=(random.nextInt(100000));
            inventory.itemCode=("0120816");
            inventory.date=("20180219");
            inventory.volume=(random.nextFloat());
            mInventories.add(inventory)
        }

        mInventoryAdapter= InventoryAdapter(context!!,mInventories)
        recycler_view_list?.adapter=mInventoryAdapter

        var listner= object:InventoryAdapter.OnDeleteClickLister{
            override fun onDeleteClick(view: View, position: Int){
                mInventories.removeAt(position)
                mInventoryAdapter?.notifyDataSetChanged()
                recycler_view_list?.closeMenu()
            }

        }

        mInventoryAdapter?.setOnDeleteClickListener(listner)

    }



}